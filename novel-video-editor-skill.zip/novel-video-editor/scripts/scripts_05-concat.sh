#!/bin/bash
# 步骤5：视频剪辑与拼接脚本
# 功能：使用FFmpeg进行素材剪辑和视频拼接

# 使用方法：
# bash 05-concat.sh material1.mp4 material2.mp4 material3.mp4
# 输出：combined_video.mp4

# 检查参数
if [ $# -lt 1 ]; then
    echo "使用方法: bash 05-concat.sh <video1> <video2> ... <videoN>"
    exit 1
fi

# 创建拼接列表
CONCAT_FILE="concat_list.txt"
> "$CONCAT_FILE"  # 清空文件

for video in "$@"; do
    if [ -f "$video" ]; then
        echo "file '$video'" >> "$CONCAT_FILE"
    else
        echo "❌ 文件不存在: $video"
        exit 1
    fi
done

echo "📦 正在拼接视频..."
echo

# FFmpeg拼接命令
ffmpeg -f concat -safe 0 -i "$CONCAT_FILE" \
    -c:v libx264 -preset medium -crf 23 \
    -c:a aac -b:a 128k \
    -y combined_video.mp4

if [ -f "combined_video.mp4" ]; then
    SIZE=$(du -h "combined_video.mp4" | cut -f1)
    echo
    echo "✅ 视频拼接成功！"
    echo "   📦 输出文件: combined_video.mp4"
    echo "   📊 文件大小: $SIZE"
else
    echo "❌ 拼接失败"
    exit 1
fi

# 清理
rm "$CONCAT_FILE"
