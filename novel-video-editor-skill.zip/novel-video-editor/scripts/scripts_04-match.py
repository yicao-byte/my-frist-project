#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
步骤4：素材库匹配脚本
功能：根据视频片段分类和时长，从素材库中智能匹配素材
"""

import pandas as pd
from typing import List, Dict

class MaterialMatcher:
    """素材匹配器 - 实现3层优先级算法"""

    def __init__(self, material_library_path):
        """初始化素材库"""
        self.df = pd.read_excel(material_library_path)
        self.materials_by_category = {}
        self._organize_by_category()

    def _organize_by_category(self):
        """按分类组织素材"""
        for category in self.df['分类'].unique():
            self.materials_by_category[category] = self.df[self.df['分类'] == category].to_dict('records')

    def match_segment(self, category: str, target_duration: int) -> Dict:
        """
        为单个视频片段匹配素材
        优先级1：精确匹配 (±5秒)
        优先级2：同类拼接 (方案2 - 优先)
        优先级3：跨类补充 (方案1 - 备选)
        """

        if category not in self.materials_by_category:
            return {'status': 'error', 'message': f'分类不存在: {category}'}

        materials = self.materials_by_category[category]

        # 优先级1：精确匹配
        for mat in materials:
            duration = int(mat['时长'])
            if abs(duration - target_duration) <= 5:
                return {
                    'method': '精确匹配',
                    'materials': [mat],
                    'total_duration': duration,
                    'status': 'success'
                }

        # 优先级2：同类多素材拼接
        combination = self._find_combination(materials, target_duration)
        if combination:
            return {
                'method': '同类拼接',
                'materials': combination['materials'],
                'total_duration': combination['total_duration'],
                'status': 'success'
            }

        # 优先级3：跨类补充
        return {
            'method': '跨类补充',
            'materials': [max(materials, key=lambda x: int(x['时长']))],
            'total_duration': int(max(materials, key=lambda x: int(x['时长']))['时长']),
            'status': 'partial'
        }

    def _find_combination(self, materials: List[Dict], target: int) -> Dict:
        """查找同类素材的组合"""
        materials_sorted = sorted(materials, key=lambda x: int(x['时长']), reverse=True)

        for i, mat1 in enumerate(materials_sorted):
            dur1 = int(mat1['时长'])
            if dur1 == target:
                return {'materials': [mat1], 'total_duration': dur1}

            for mat2 in materials_sorted[i+1:]:
                dur2 = int(mat2['时长'])
                if dur1 + dur2 == target:
                    return {'materials': [mat1, mat2], 'total_duration': dur1 + dur2}

        return None

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 3:
        print("使用方法: python3 04-match.py <library.xlsx> <category> <duration>")
        sys.exit(1)

    matcher = MaterialMatcher(sys.argv[1])
    result = matcher.match_segment(sys.argv[2], int(sys.argv[3]))
    print("【素材匹配方案】")
    print(f"分类: {sys.argv[2]}")
    print(f"目标时长: {sys.argv[3]}s")
    print(f"方法: {result['method']}")
    print(f"总时长: {result['total_duration']}s")
