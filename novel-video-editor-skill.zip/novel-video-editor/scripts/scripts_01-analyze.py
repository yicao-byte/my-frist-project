#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
步骤3：视频内容分析脚本
功能：分析原视频，识别>20秒的素材片段
"""

import subprocess
import json
from pathlib import Path

def get_video_metadata(video_file):
    """获取视频元数据"""
    cmd = [
        'ffprobe',
        '-v', 'error',
        '-show_entries', 'format=duration,width,height',
        '-show_entries', 'stream=r_frame_rate,codec_name',
        '-of', 'json',
        video_file
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)

def analyze_video(video_file):
    """分析视频内容"""
    metadata = get_video_metadata(video_file)

    duration = float(metadata['format']['duration'])
    width = metadata['streams'][0]['width']
    height = metadata['streams'][0]['height']

    print("【原视频结构分析】")
    print(f"文件: {Path(video_file).name}")
    print(f"总时长: {int(duration)}s")
    print(f"分辨率: {width}×{height}")
    print(f"帧率: {metadata['streams'][0].get('r_frame_rate', 'unknown')}")
    print()

    return {
        'duration': duration,
        'width': width,
        'height': height,
        'filename': str(video_file)
    }

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("使用方法: python3 01-analyze.py <video_file>")
        sys.exit(1)

    analyze_video(sys.argv[1])
