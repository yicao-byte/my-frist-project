#!/bin/bash
# 步骤7：音频与字幕处理脚本
# 功能：将音频和字幕集成到视频中

if [ $# -lt 2 ]; then
    echo "使用方法:"
    echo "  bash 07-audio-subtitle.sh <video> <audio> [subtitle]"
    echo "示例:"
    echo "  bash 07-audio-subtitle.sh video.mp4 audio.mp3 subtitles.srt"
    exit 1
fi

VIDEO="$1"
AUDIO="$2"
SUBTITLE="${3:-}"

echo "📦 处理音频与字幕..."
echo

# 添加音频
if [ -n "$AUDIO" ] && [ -f "$AUDIO" ]; then
    echo "🎵 添加音频..."
    ffmpeg -i "$VIDEO" -i "$AUDIO" \
        -c:v copy -c:a aac \
        -map 0:v:0 -map 1:a:0 \
        -shortest -y output_with_audio.mp4

    if [ -f "output_with_audio.mp4" ]; then
        echo "✅ 音频已添加"
    else
        echo "❌ 音频添加失败"
        exit 1
    fi
else
    echo "⏭️  跳过音频 (文件不存在)"
    cp "$VIDEO" output_with_audio.mp4
fi

# 添加字幕
if [ -n "$SUBTITLE" ] && [ -f "$SUBTITLE" ]; then
    echo "📝 添加字幕..."
    ffmpeg -i output_with_audio.mp4 -i "$SUBTITLE" \
        -c:v copy -c:a copy \
        -c:s mov_text \
        -metadata:s:s:0 language=zho \
        -y final_with_subtitles.mp4

    if [ -f "final_with_subtitles.mp4" ]; then
        echo "✅ 字幕已添加"
        rm output_with_audio.mp4
    else
        echo "❌ 字幕添加失败"
        exit 1
    fi
else
    echo "⏭️  跳过字幕 (文件不存在)"
    mv output_with_audio.mp4 final_with_subtitles.mp4
fi

echo
echo "✅ 音字处理完成！"
echo "   📹 输出文件: final_with_subtitles.mp4"
