#!/bin/bash
# 步骤8&9：水印与尾贴处理脚本
# 功能：添加水印和尾贴

if [ $# -lt 2 ]; then
    echo "使用方法:"
    echo "  bash 08-watermark-endcard.sh <video> <watermark> [endcard]"
    echo "示例:"
    echo "  bash 08-watermark-endcard.sh video.mp4 watermark.png end_card.mp4"
    exit 1
fi

VIDEO="$1"
WATERMARK="$2"
ENDCARD="${3:-}"

echo "🎨 添加水印与尾贴..."
echo

# 添加水印
if [ -f "$WATERMARK" ]; then
    echo "🎨 添加水印..."
    ffmpeg -i "$VIDEO" \
        -i "$WATERMARK" \
        -filter_complex "[1:v]scale=115:69[scaled];[0:v][scaled]overlay=x=1805:y=0" \
        -c:a copy -y video_with_watermark.mp4

    if [ -f "video_with_watermark.mp4" ]; then
        echo "✅ 水印已添加 (右上角23%)"
    else
        echo "❌ 水印添加失败"
        exit 1
    fi
else
    echo "❌ 水印文件不存在: $WATERMARK"
    exit 1
fi

# 添加尾贴
if [ -n "$ENDCARD" ] && [ -f "$ENDCARD" ]; then
    echo "🏁 添加尾贴..."

    # 分辨率校准
    ffmpeg -i "$ENDCARD" \
        -vf "scale=1920:1080" \
        -c:v libx264 -c:a aac -y end_card_scaled.mp4

    # 创建拼接列表
    cat > concat_final.txt << EOF
file 'video_with_watermark.mp4'
file 'end_card_scaled.mp4'
EOF

    # 拼接
    ffmpeg -f concat -safe 0 -i concat_final.txt \
        -c:v copy -c:a copy -y final_output.mp4

    if [ -f "final_output.mp4" ]; then
        echo "✅ 尾贴已添加 (末尾5秒)"
        rm concat_final.txt end_card_scaled.mp4 video_with_watermark.mp4
    else
        echo "❌ 尾贴添加失败"
        exit 1
    fi
else
    echo "⏭️  跳过尾贴"
    mv video_with_watermark.mp4 final_output.mp4
fi

echo
echo "✅ 水印与尾贴处理完成！"
echo "   📹 输出文件: final_output.mp4"
